package com.aquariumglass.util;

import cpw.mods.fml.common.Mod.EventHandler;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.player.PlayerEvent;

public class ElectricDamageSource extends DamageSource {

	public ElectricDamageSource(String p_i1566_1_) {
		super(p_i1566_1_);
		
	}
	

}
